<?php
file_put_contents("entries.log", "");
header('Location: /');
?>

